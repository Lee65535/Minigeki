#pragma once

namespace component {
    namespace jvsio {
        void start();
        void update();
    }
}
